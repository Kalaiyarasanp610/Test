﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Assignment.Models;
using System.Net;
using System.Text;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;

namespace Assignment.Controllers
{
    public class HomeController : Controller
    {
        public IConfiguration configuration;
        public HomeController(IConfiguration config)
        {
            configuration = config;
        }
        public async Task<IActionResult> Index()
        {
            payment model = new payment();

            object objInput = new { };

            WebClient client = new WebClient();
            client.Headers["Content-type"] = "application/json";
            client.Encoding = Encoding.UTF8;

            string jsonParams = JsonConvert.SerializeObject(objInput);

            string webApi = configuration.GetSection("WebAPI").Value.ToString();

            string str = client.UploadString(webApi + "Payment/GetPaymentOptions", jsonParams);

            List<payoptions> payoptions = JsonConvert.DeserializeObject<List<payoptions>>(str);

            model.payOptions = payoptions.Select(item => new SelectListItem { Value = item.Id.ToString(), Text = item.Name }).ToList();

            return View(model);
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public async Task<IActionResult> submit(payment _payment)
        {
            try
            {
                //if (!ModelState.IsValid)
                //{
                //    return RedirectToPage("Home");
                //}


                object objInput = new
                {
                    name = _payment.name,
                    cardno = _payment.cardno,
                    expieryon = _payment.expieryon,
                    cvv = _payment.cvv
                };

                WebClient client = new WebClient();
                client.Headers["Content-type"] = "application/json";
                client.Encoding = Encoding.UTF8;

                string jsonParams = JsonConvert.SerializeObject(objInput);
                string webApi = configuration.GetSection("WebAPI").Value.ToString();

                string str = client.UploadString(webApi + "Payment/PostPayment", jsonParams);

                return View();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        [HttpPost]
        public string Paynow(paymentDetails paymentDetails)
        {
            object objInput = new
            {
                amount = paymentDetails.amount,
                payType = paymentDetails.payType,
                name = paymentDetails.name,
                cardno = paymentDetails.cardno,
                expieryonMonth = paymentDetails.expieryonMonth,
                expieryonYear = paymentDetails.expieryonYear,
                cvv = paymentDetails.cvv,
                userName = paymentDetails.userName,
                password = paymentDetails.password
            };

            WebClient client = new WebClient();
            client.Headers["Content-type"] = "application/json";
            client.Encoding = Encoding.UTF8;

            string jsonParams = JsonConvert.SerializeObject(objInput);

            string webApi = configuration.GetSection("WebAPI").Value.ToString();
            string str = client.UploadString(webApi + "Payment/PostPayment", jsonParams);

            return str;
        }
        [HttpPost]
        public string ProccessPayment(paymentDetails paymentDetails)
        {
            object objInput = new
            {
                referenceId = paymentDetails.referenceId,
            };

            WebClient client = new WebClient();
            client.Headers["Content-type"] = "application/json";
            client.Encoding = Encoding.UTF8;

            string jsonParams = JsonConvert.SerializeObject(objInput);
            string webApi = configuration.GetSection("WebAPI").Value.ToString();

            string str = client.UploadString(webApi + "Payment/ProccessPayment", jsonParams);

            return str;
        }
    }
}
