﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment.Models
{
    public class payment
    {
        [Required(AllowEmptyStrings = false, ErrorMessage =  "Card number required")]
        [StringLength(16, ErrorMessage ="Invalid card number")]
        public Int64 cardno { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage =  "Expiery on required")]
        public string expieryon { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage =  "CVV required")]
        [StringLength(3, ErrorMessage ="Invalid CVV")]
        public Int32 cvv { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage =  "Name required")]
        public string name { get; set; }
        public string selPayOptions { get; set; }
        public List<SelectListItem> payOptions { get; set; }
    }
    public class payoptions
    {
        public Int32 Id { get; set; }
        public string Name { get; set; }
    }
    public class paymentDetails
    {
        public string amount { get; set; }
        public string payType { get; set; }
        public string name { get; set; }
        public string cardno { get; set; }
        public string expieryonMonth { get; set; }
        public string expieryonYear { get; set; }
        public string cvv { get; set; }
        public string referenceId { get; set; }
        public string userName { get; set; }
        public string password { get; set; }
    }
}
