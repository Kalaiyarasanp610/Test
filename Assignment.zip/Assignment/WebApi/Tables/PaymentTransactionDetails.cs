﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Tables
{
    [Table("PaymentTransactionDetails")]
    public class PaymentTransactionDetails
    {
        [Key]
        public int ptId { get; set; }
        public int ptReferenceId { get; set; }
        public string ptTransactionType { get; set; }
        public double ptTransactionAmount { get; set; }
        public Int64 ptCardNo { get; set; }
        public string ptNetbankUser { get; set; }
        public int ptPaymentStatus { get; set; }
        public int ptOTP { get; set; }
        public bool ptStatus { get; set; }
        public DateTime ptCreatedDate { get; set; }
        public string ptCreatedBy { get; set; }
    }
}
