﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Tables
{
    [Table("PaymentOptions")]
    public class PaymentOptions
    {
        [Key]
        public Int32 poId { get; set; }
        public string poType { get; set; }
        public string poDesc { get; set; }
        public bool poStatus { get; set; }
        public DateTime poCreatedDate { get; set; }
        public string poCreatedBy { get; set; }
    }
}
