﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Tables
{
    [Table("ReportTable")]
    public class ReportTable
    {
        [Key]
        public int rtId { get; set; }
        public int rtptId { get; set; }
        public double rtAmount { get; set; }
        public string rtTransactionType { get; set; }
        public string rtTransactionStatus { get; set; }
        public bool rtStatus { get; set; }
        public string rtCreatedBy { get; set; }
        public DateTime rtCreatedDateTime { get; set; }
    }
}
