﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Tables
{
    [Table("NetbankingAccessDetails")]
    public class NetbankingAccessDetails
    {
        [Key]
        public int nbId { get; set; }
        public string nbUserName { get; set; }
        public string nbPassword { get; set; }
        public string nbBankName { get; set; }
        public bool nbStatus { get; set; }
        public string nbCreatedBy { get; set; }
        public DateTime nbCreatedDate { get; set; }
    }
}
