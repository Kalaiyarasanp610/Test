﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Tables
{
    [Table("CardAccessDetails")]
    public class CardAccessDetails
    {
        [Key]
        public int caId {get;set;}
        public Int64 caCardNo { get;set; }
        public int caExpieryMonth { get;set;}
        public int caExpieryYear { get;set;}
        public int caCVV { get;set;}
        public string caNameonCard { get;set; }
        public bool caStatus { get;set; }
        public string caCreatedBy { get;set; }
        public DateTime caCreatedDate { get;set; }
    }
}
