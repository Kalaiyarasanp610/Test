﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Tables
{
    [Table("PaymentDetails")]
    public class PaymentDetails
    {
        [Key]
        public Int32 payId { get; set; }
        public string payName { get; set; }
        public string expieryon { get; set; }
    }
}
