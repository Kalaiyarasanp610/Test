﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApi.Models;
using WebApi.UnitofWork;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentController : ControllerBase
    {
        private readonly IUnitofWork _unitofwork;
        public PaymentController(IUnitofWork unitofwork)
        {
            _unitofwork = unitofwork;
        }
        [Route("PostPayment")]
        public IActionResult ProcessPayment(inputParams inputParams)
        {
            try
            {
                string result = _unitofwork.setPaymentRepository.Authentication(inputParams);
                return Ok(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        [Route("ProccessPayment")]
        public IActionResult StartProccessPayment(inputParams inputParams)
        {
            try
            {
                string result = _unitofwork.setPaymentRepository.PaymentProcess(inputParams);
                return Ok(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        [Route("GetPaymentOptions")]
        public IActionResult FetchPaymentOptions()
        {
            try
            {
                List<paymentOptionsValue> result = _unitofwork.setPaymentRepository.GetPaymentOptions();
                return Ok(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}