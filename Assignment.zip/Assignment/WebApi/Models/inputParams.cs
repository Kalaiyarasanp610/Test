﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Models
{
    public class inputParams
    {
        public string amount { get; set; }
        public int? payType { get; set; }
        public string name { get; set; }
        public string cardno { get; set; }
        public int? expieryonMonth { get; set; }
        public int? expieryonYear { get; set; }
        public string cvv { get; set; }
        public string userName { get; set; }
        public string password { get; set; }
        public int? referenceId { get; set; }
    }
}
