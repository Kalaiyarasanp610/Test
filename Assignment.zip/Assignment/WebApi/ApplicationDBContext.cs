﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Tables;

namespace WebApi
{
    public class ApplicationDBContext : DbContext
    {
        public ApplicationDBContext(DbContextOptions<ApplicationDBContext> options)
            : base(options)
        {
            //Database.SetInitializer<ApplicationDBContext>(null);
        }
        public DbSet<PaymentDetails> PaymentDetails { get; set; }
        public DbSet<PaymentOptions> PaymentOptions { get; set; }
        public DbSet<CardAccessDetails> CardAccessDetails { get; set; }
        public DbSet<NetbankingAccessDetails> NetbankingAccessDetails { get; set; }
        public DbSet<PaymentTransactionDetails> PaymentTransactionDetails { get; set; }
        public DbSet<ReportTable> ReportTable { get; set; }
    }
}
