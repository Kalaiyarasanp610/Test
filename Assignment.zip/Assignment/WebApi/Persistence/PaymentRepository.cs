﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Models;
using WebApi.Repositories;
using WebApi.Tables;

namespace WebApi.Persistence
{
    public class PaymentRepository : IPaymentRepository
    {
        public readonly ApplicationDBContext _context;
        public PaymentRepository(ApplicationDBContext context)
        {
            _context = context;
        }
        public List<paymentOptionsValue> GetPaymentOptions()
        {
            try
            {
                List<paymentOptionsValue> paymentOptionsValues = (from po in _context.PaymentOptions
                                                                  where po.poStatus
                                                                  select new paymentOptionsValue
                                                                  {
                                                                      Id = po.poId,
                                                                      Name = po.poType
                                                                  }).ToList();
                return paymentOptionsValues;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string Authentication(inputParams inputParams)
        {
            try
            {
                if (inputParams.payType == 1)
                {
                    var ccid = (from ca in _context.CardAccessDetails
                                where ca.caCardNo == Convert.ToInt64(inputParams.cardno) && ca.caCVV == Convert.ToInt32(inputParams.cvv)
                                   && ca.caNameonCard == inputParams.name && ca.caExpieryMonth == inputParams.expieryonMonth
                                   && ca.caExpieryYear == inputParams.expieryonYear && ca.caStatus
                                select new { ca.caId }
                                ).FirstOrDefault();
                    if (ccid != null)
                    {
                        PaymentTransactionDetails pt = new PaymentTransactionDetails();

                        pt.ptReferenceId = ccid.caId;
                        pt.ptTransactionType = inputParams.payType.ToString();
                        pt.ptTransactionAmount = Convert.ToDouble(inputParams.amount);
                        pt.ptCardNo = Convert.ToInt64(inputParams.cardno);
                        pt.ptPaymentStatus = 2;
                        pt.ptOTP = 123456;
                        pt.ptStatus = true;
                        pt.ptCreatedBy = "Test User";
                        pt.ptCreatedDate = DateTime.Now;

                        _context.Add(pt);
                        int a = _context.SaveChanges();

                        return pt.ptId + "|" + pt.ptOTP;
                    }
                    return "0|0";
                }
                else
                {
                    var ccid = (from nb in _context.NetbankingAccessDetails
                                where nb.nbUserName == inputParams.userName && nb.nbPassword == inputParams.password
                                   && nb.nbStatus
                                select new { nb.nbId }
                                ).FirstOrDefault();
                    if (ccid != null)
                    {
                        PaymentTransactionDetails pt = new PaymentTransactionDetails();

                        pt.ptReferenceId = ccid.nbId;
                        pt.ptTransactionType = inputParams.payType.ToString();
                        pt.ptTransactionAmount = Convert.ToDouble(inputParams.amount);
                        pt.ptNetbankUser = inputParams.userName;
                        pt.ptPaymentStatus = 2;
                        pt.ptOTP = 123456;
                        pt.ptStatus = true;
                        pt.ptCreatedBy = "Test User";
                        pt.ptCreatedDate = DateTime.Now;

                        _context.Add(pt);
                        int a = _context.SaveChanges();

                        return pt.ptId + "|" + pt.ptOTP;
                    }
                    return "0|0";
                }
                return "0|0";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string PaymentProcess(inputParams inputParams)
        {
            try
            {
                var ptd =
                    (from pt in _context.PaymentTransactionDetails
                     where pt.ptStatus && pt.ptId == inputParams.referenceId
                     select pt
                 ).FirstOrDefault();

                ptd.ptPaymentStatus = 1;

                int result = _context.SaveChanges();

                return result.ToString();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
