﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Persistence;
using WebApi.Repositories;

namespace WebApi.UnitofWork
{
    public class UnitofWork : IUnitofWork
    {
        public readonly ApplicationDBContext _context;
        public IPaymentRepository setPaymentRepository { get; private set; }

        public UnitofWork(ApplicationDBContext context)
        {
            setPaymentRepository = new  PaymentRepository(context);
        }
        public void Complete()
        {
            throw new NotImplementedException();
        }
    }
}
