﻿using Hangfire;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Jobs
{
    public class HangfireJobScheduler
    {
        public static void ScheduleRecurringJobs()
        {
        }
    }
}
