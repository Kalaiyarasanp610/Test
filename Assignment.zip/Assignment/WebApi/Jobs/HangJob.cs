﻿using Hangfire;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Tables;

namespace WebApi.Jobs
{
    public interface IHangJob
    {
        Task RunAtTimeOf(DateTime now);
    }
    public class HangJob : IHangJob
    {
        //private readonly ILogger<HangJob> _logger;
        private readonly ApplicationDBContext _context;

        public HangJob(ApplicationDBContext context)
        {
            _context = context;
        }
        public async Task Run(IJobCancellationToken token)
        {
            token.ThrowIfCancellationRequested();
            await RunAtTimeOf(DateTime.Now);
        }
        public async Task RunAtTimeOf(DateTime now)
        {
            try
            {
                List<ReportTable> reportTable = new List<ReportTable>();


                var rep = (from rt in _context.ReportTable select rt).ToList();

                if (rep == null)
                {
                    reportTable = (from pt in _context.PaymentTransactionDetails
                                   select new ReportTable
                                   {
                                       rtptId = pt.ptId,
                                       rtAmount = Convert.ToDouble(pt.ptTransactionAmount),
                                       rtTransactionStatus = pt.ptPaymentStatus == 1 ? "Success" : pt.ptPaymentStatus == 2 ? "Pending" : "Cancelled",
                                       rtTransactionType = pt.ptTransactionType == "1" ? "Card" : "Netbanking",
                                       rtCreatedBy = "ReportJob User",
                                       rtCreatedDateTime = DateTime.Now,
                                       rtStatus = true
                                   }).ToList();
                }
                else
                {
                    int maxVal = _context.ReportTable.Max(p => p.rtptId);

                    reportTable = (from pt in _context.PaymentTransactionDetails
                                   where pt.ptId > maxVal
                                   select new ReportTable
                                   {
                                       rtptId = pt.ptId,
                                       rtAmount = Convert.ToDouble(pt.ptTransactionAmount),
                                       rtTransactionStatus = pt.ptPaymentStatus == 1 ? "Success" : pt.ptPaymentStatus == 2 ? "Pending" : "Cancelled",
                                       rtTransactionType = pt.ptTransactionType == "1" ? "Card" : "Netbanking",
                                       rtCreatedBy = "ReportJob User",
                                       rtCreatedDateTime = DateTime.Now,
                                       rtStatus = true
                                   }).ToList();

                }
                _context.AddRange(reportTable);
                _context.SaveChanges();

                await _context.SaveChangesAsync();
            }
            catch(Exception ex)
            {
                //throw ex;
            }
        }

    }
}
