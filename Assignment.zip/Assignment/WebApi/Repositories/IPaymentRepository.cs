﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Models;

namespace WebApi.Repositories
{
    public interface IPaymentRepository
    {
        string Authentication(inputParams inputParams);
        List<paymentOptionsValue> GetPaymentOptions();
        string PaymentProcess(inputParams inputParams);
    }
}
